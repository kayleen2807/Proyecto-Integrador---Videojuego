import pygame
import pytmx
import sys
from button import Button

pygame.init()

# Configuración de pantalla
pantalla = pygame.display.set_mode((1280, 720))
pygame.display.set_caption("Menu principal")

# Función para cargar fuente
def get_font(size):
    return pygame.font.Font("assets/font.ttf", size)

# Pantalla principal del juego
def play():
    pygame.display.set_caption("Play")

    # Cargar mapa
    tmx_data = pytmx.util_pygame.load_pygame("mapa_prueba.tmx")

    # Cargar colisiones desde los tiles colocados en el mapa
    # Cargar colisiones desde objetos del mapa
    colisiones = []
    for obj in tmx_data.objects:
        colisiones.append(pygame.Rect(obj.x, obj.y, obj.width, obj.height))

    # Personaje
    personaje = pygame.Rect(100, 80 * tmx_data.tileheight, 50, 50)
    vel_y = 0
    en_el_suelo = False
    gravedad = 1

    while True:
        mouse_pos = pygame.mouse.get_pos()
        pantalla.fill("black")

        # Movimiento horizontal
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            personaje.x -= 5
        if keys[pygame.K_RIGHT]:
            personaje.x += 5

        # Detección de colisiones horizontales
        for rect in colisiones:
            if personaje.colliderect(rect):
                if keys[pygame.K_LEFT]:
                    personaje.left = rect.right
                elif keys[pygame.K_RIGHT]:
                    personaje.right = rect.left

        # Salto
        if keys[pygame.K_SPACE] and en_el_suelo:
            vel_y = -15
            en_el_suelo = False

        # Aplicar gravedad
        vel_y += gravedad
        personaje.y += vel_y

        # Detección de colisiones verticales
        en_el_suelo = False
        for rect in colisiones:
            if personaje.colliderect(rect):
                if vel_y > 0:  # cayendo
                    personaje.bottom = rect.top
                    vel_y = 0
                    en_el_suelo = True
                elif vel_y < 0:  # subiendo
                    personaje.top = rect.bottom
                    vel_y = 0

        # Recalcular cámara cada frame
        camara_x = personaje.x - pantalla.get_width() // 2 + personaje.width // 2
        camara_y = personaje.y - pantalla.get_height() // 2 + personaje.height // 2

        # Dibujar mapa con desplazamiento
        for layer in tmx_data.visible_layers:
            if isinstance(layer, pytmx.TiledTileLayer):
                for x, y, gid in layer:
                    tile = tmx_data.get_tile_image_by_gid(gid)
                    if tile:
                        pantalla.blit(tile, (x * tmx_data.tilewidth - camara_x, y * tmx_data.tileheight - camara_y))

        # Dibujar personaje con desplazamiento
        pygame.draw.rect(pantalla, (0, 255, 0), pygame.Rect(personaje.x - camara_x, personaje.y - camara_y, personaje.width, personaje.height))

        # Botón para regresar al menú
        boton_atras = Button(image=None, pos=(640, 460), text_input="ATRAS", font=get_font(15), base_color="White", hovering_color="Blue")
        boton_atras.changeColor(mouse_pos)
        boton_atras.update(pantalla)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "salir"
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if boton_atras.checkForInput(mouse_pos):
                    return "menu"

        pygame.display.update()

# Pantalla de opciones
def opciones():
    pygame.display.set_caption("Opciones")
    while True:
        mouse_pos = pygame.mouse.get_pos()
        pantalla.fill("White")

        texto = get_font(15).render("Estas seran las opciones", True, "Black")
        texto_rect = texto.get_rect(center=(640, 260))
        pantalla.blit(texto, texto_rect)

        boton_back = Button(image=None, pos=(640, 460), text_input="BACK", font=get_font(15), base_color="Black", hovering_color="Blue")
        boton_back.changeColor(mouse_pos)
        boton_back.update(pantalla)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "salir"
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if boton_back.checkForInput(mouse_pos):
                    return "menu"

        pygame.display.update()

# Pantalla de inicio
def inicio():
    pygame.display.set_caption("Inicio")
    while True:
        mouse_pos = pygame.mouse.get_pos()
        pantalla.fill("black")

        texto = get_font(80).render("Bienvenido", True, "White")
        texto_rect = texto.get_rect(center=(640, 200))
        pantalla.blit(texto, texto_rect)

        boton_empezar = Button(image=None, pos=(640, 400), text_input="EMPEZAR", font=get_font(45), base_color="White", hovering_color="Blue")
        boton_empezar.changeColor(mouse_pos)
        boton_empezar.update(pantalla)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "salir"
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if boton_empezar.checkForInput(mouse_pos):
                    return "menu"

        pygame.display.update()

# Menú principal
def menu_prin():
    pygame.display.set_caption("Menu principal")
    while True:
        mouse_pos = pygame.mouse.get_pos()
        pantalla.fill("black")

        texto = get_font(60).render("MENU PRINCIPAL", True, "#b68f40")
        texto_rect = texto.get_rect(center=(640, 100))
        pantalla.blit(texto, texto_rect)

        boton_play = Button(image=None, pos=(640, 250), text_input="PLAY", font=get_font(35), base_color="#d7fcd4", hovering_color="White")
        boton_opciones = Button(image=None, pos=(640, 400), text_input="OPTIONS", font=get_font(35), base_color="#d7fcd4", hovering_color="White")
        boton_salir = Button(image=None, pos=(640, 550), text_input="QUIT", font=get_font(35), base_color="#d7fcd4", hovering_color="White")

        for boton in [boton_play, boton_opciones, boton_salir]:
            boton.changeColor(mouse_pos)
            boton.update(pantalla)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "salir"
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if boton_play.checkForInput(mouse_pos):
                    return "play"
                elif boton_opciones.checkForInput(mouse_pos):
                    return "opciones"
                elif boton_salir.checkForInput(mouse_pos):
                    return "salir"

        pygame.display.update()

# Bucle principal del juego
def main():
    pantalla_actual = "inicio"
    while True: 
        if pantalla_actual == "inicio":
            pantalla_actual = inicio()
        elif pantalla_actual == "menu":
            pantalla_actual = menu_prin()
        elif pantalla_actual == "play":
            pantalla_actual = play()
        elif pantalla_actual == "opciones":
            pantalla_actual = opciones()
        elif pantalla_actual == "salir":
            pygame.quit()
            sys.exit()
try:
    main()
except Exception as e:
    print("¡Error detectado!")
    print(e)